=== Plugin Name ===
Contributors: Cypress North
Tags: shotcodes, widgets
Requires at least: 3.0.1
Tested up to: 3.9.2
License: GPLv2 or later
License URI: http://www.gnu.org/licenses/gpl-2.0.html

A Wordpress Plugin to enable the use of shortcodes in sidebar widgets

== Description ==

A Wordpress Plugin to enable the use of shortcodes in sidebar widgets

Once enabled, add a Text widget to your sidebar and enter the shortcode into the widget body.

== Installation ==

1. Upload the 'cn-enable-widget-shortcodes' directory to the `/wp-content/plugins/` directory
1. Activate the plugin through the 'Plugins' menu in WordPress
1. Place a Text widget into your sidebar and enter your shortcode into the widget body

== Changelog ==

= 1.0 =
* Initial Creation